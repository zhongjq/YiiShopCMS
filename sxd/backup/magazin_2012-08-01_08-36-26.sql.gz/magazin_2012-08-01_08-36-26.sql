#SXD20|20009|50163|50303|2012.08.01 08:36:26|magazin|0|9|8|
#TA Categories`5`16384|NumericFields`0`16384|PriceFields`0`16384|Products`1`16384|ProductsFields`0`16384|StringFields`0`16384|TextFields`0`16384|Users`2`16384|tires`0`16384
#EOH

#	TC`Categories`utf8_general_ci	;
CREATE TABLE `Categories` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `root` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned NOT NULL,
  `rgt` int(10) unsigned NOT NULL,
  `Level` smallint(5) unsigned NOT NULL,
  `Status` int(1) NOT NULL COMMENT 'Тип категории',
  `Alias` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Категории'	;
#	TD`Categories`utf8_general_ci	;
INSERT INTO `Categories` VALUES 
(1,1,1,8,1,1,'shiny','Шины','Шины'),
(2,2,1,2,1,1,'diski','Диски','Диски'),
(3,1,2,3,2,1,'letnie','Летние','Летние'),
(4,1,4,5,2,1,'zimnie','Зимние','Зимние'),
(5,1,6,7,2,1,'vsesezonnye','Всесезонные','Всесезонные')	;
#	TC`NumericFields`utf8_general_ci	;
CREATE TABLE `NumericFields` (
  `FieldID` int(11) NOT NULL,
  `MinValue` int(11) NOT NULL COMMENT 'От',
  `MaxValue` int(11) NOT NULL COMMENT 'Да',
  `NumberOfDecimalPlaces` int(11) NOT NULL COMMENT 'Количество знаков после запятой',
  PRIMARY KEY (`FieldID`),
  CONSTRAINT `NumericFields_ibfk_1` FOREIGN KEY (`FieldID`) REFERENCES `ProductsFields` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Числовые поля'	;
#	TC`PriceFields`utf8_general_ci	;
CREATE TABLE `PriceFields` (
  `FieldID` int(11) NOT NULL,
  `MaxValue` int(11) NOT NULL COMMENT 'Да',
  PRIMARY KEY (`FieldID`),
  CONSTRAINT `PriceFields_ibfk_1` FOREIGN KEY (`FieldID`) REFERENCES `ProductsFields` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ценовые поля'	;
#	TC`Products`utf8_general_ci	;
CREATE TABLE `Products` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Status` tinyint(1) NOT NULL DEFAULT '1',
  `Name` varchar(255) NOT NULL,
  `Alias` varchar(255) NOT NULL,
  `Title` text NOT NULL,
  `Keywords` text NOT NULL,
  `Description` text NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Status` (`Status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Таблица продуктов магазина'	;
#	TD`Products`utf8_general_ci	;
INSERT INTO `Products` VALUES 
(1,1,'Шины','tires','','','')	;
#	TC`ProductsFields`utf8_general_ci	;
CREATE TABLE `ProductsFields` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Position` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `FieldType` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Alias` varchar(50) NOT NULL,
  `IsMandatory` tinyint(1) NOT NULL DEFAULT '0',
  `IsFilter` tinyint(1) NOT NULL DEFAULT '0',
  `IsColumnTable` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'используется в заголовке таблицы',
  `UnitName` varchar(255) NOT NULL COMMENT 'Единицы измерения',
  `Hint` varchar(255) NOT NULL COMMENT 'Подсказка',
  PRIMARY KEY (`ID`),
  KEY `ProductID` (`ProductID`),
  CONSTRAINT `ProductsFields_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `Products` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`StringFields`utf8_general_ci	;
CREATE TABLE `StringFields` (
  `FieldID` int(11) NOT NULL,
  `MinLength` int(3) NOT NULL DEFAULT '0' COMMENT 'Минимальная длинна',
  `MaxLength` int(3) NOT NULL DEFAULT '255' COMMENT 'Максимальная длинна',
  PRIMARY KEY (`FieldID`),
  CONSTRAINT `StringFields_ibfk_1` FOREIGN KEY (`FieldID`) REFERENCES `ProductsFields` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Строковые поля'	;
#	TC`TextFields`utf8_general_ci	;
CREATE TABLE `TextFields` (
  `FieldID` int(11) NOT NULL,
  `MinLength` int(11) NOT NULL DEFAULT '0' COMMENT 'Минимальная длинна',
  `MaxLength` int(11) NOT NULL DEFAULT '10000' COMMENT 'Максимальная длинна',
  `Rows` int(11) NOT NULL DEFAULT '5' COMMENT 'Строк',
  PRIMARY KEY (`FieldID`),
  CONSTRAINT `TextFields_ibfk_1` FOREIGN KEY (`FieldID`) REFERENCES `ProductsFields` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Текстовые поля'	;
#	TC`Users`utf8_general_ci	;
CREATE TABLE `Users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Включен/Выключен',
  `RoleID` int(5) DEFAULT '1' COMMENT 'Номер роли',
  `RegistrationDateTime` datetime DEFAULT NULL COMMENT 'Дата и время регистрации',
  `ServiceID` int(5) DEFAULT '1' COMMENT 'Идентификатор сервиса (1 - локальный пользователь)',
  `ServiceUserID` varchar(255) DEFAULT NULL COMMENT 'Идентификатор пользователя в сервисе',
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Таблица пользователей'	;
#	TD`Users`utf8_general_ci	;
INSERT INTO `Users` VALUES 
(1,0,2,'2012-06-30 20:17:00',1,'','enchikiben@gmail.com','a37e9e0ada9d5eef566727a9a8ea36e8',\N),
(2,0,1,'2012-07-04 00:41:25',3,'http://openid.yandex.ru/EnChikiben/',\N,\N,'EnChikiben')	;
#	TC`tires`utf8_general_ci	;
CREATE TABLE `tires` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Alias` varchar(255) DEFAULT NULL,
  `Title` text,
  `Keywords` text,
  `Description` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
