#SXD20|20009|50163|50303|2012.07.04 00:40:26|magazin|utf8|1|1|
#TA Users`1`16384
#EOH

#	TC`Users`utf8_general_ci	;
CREATE TABLE `Users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Включен/Выключен',
  `RoleID` int(5) DEFAULT '1' COMMENT 'Номер роли',
  `RegistrationDateTime` datetime DEFAULT NULL COMMENT 'Дата и время регистрации',
  `ServiceID` int(5) DEFAULT '1' COMMENT 'Идентификатор сервиса (1 - локальный пользователь)',
  `ServiceUserID` varchar(255) DEFAULT NULL COMMENT 'Идентификатор пользователя в сервисе',
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Таблица пользователей'	;
#	TD`Users`utf8_general_ci	;
INSERT INTO `Users` VALUES 
(1,0,2,'2012-06-30 20:17:00',1,'','enchikiben@gmail.com','a37e9e0ada9d5eef566727a9a8ea36e8',\N)	;
